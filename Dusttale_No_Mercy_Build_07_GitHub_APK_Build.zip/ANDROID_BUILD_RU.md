# Подготовка Android-сборки — Dusttale: No Mercy 0.7.1

## Что подготовлено
- Исправлена ориентация Android: альбомная (landscape), значение Godot `0`.
- Добавлена версия приложения `0.7.1` и Android export preset `Android`.
- Выбрана архитектура `arm64-v8a`; имя приложения — `Dusttale: No Mercy`.
- Путь результата: `build/Dusttale_No_Mercy_0.7.1.apk`.

## Что требуется для фактического APK
Нужны Godot 4.3 с Export Templates той же версии, Android SDK (Platform, Build-Tools, Platform-Tools) и настроенный путь к JDK. В Godot открой Editor Settings → Export → Android и укажи пути к Java SDK и Android SDK.

## Сборка
Открой `project.godot` в Godot 4.3, проверь Android preset в Project → Export и нажми Export Project. Выбери `build/Dusttale_No_Mercy_0.7.1.apk`.

## Честное ограничение текущей среды
В рабочей среде Godot, Android SDK и Android export templates отсутствуют, а сетевой доступ для их установки недоступен. Поэтому APK здесь не собран и запуск игры в движке не подтверждён. Этот архив — подготовленный исходный проект для экспорта, а не готовый APK.

## Состояние игры
Build 0.7.1 остаётся прототипом: визуальные персонажи процедурные, а папки изображений и звука содержат README-заглушки. Перед публикацией нужно проверить GDScript в Godot и пройти игровой сценарий на устройстве.

## Автоматическая сборка через GitHub Actions

В проект добавлен файл `.github/workflows/android-apk.yml`. Он использует контейнер `barichello/godot-ci:4.3` с Godot 4.3, Android SDK и экспортными шаблонами.

1. Создай пустой репозиторий GitHub.
2. Загрузи в него **содержимое папки `Dusttale_Android_Project`**, чтобы `project.godot` и папка `.github` находились в корне репозитория.
3. Открой вкладку **Actions** и разреши запуск workflows, если GitHub попросит.
4. Запусти workflow **Build Android APK** через кнопку **Run workflow** (или отправь commit в `main`/`master`).
5. Когда задача завершится успешно, открой её страницу и скачай artifact `Dusttale-No-Mercy-Android-APK`.

Это будет debug APK для установки и тестирования. Для публикации в магазине потребуется отдельная release-подпись. Секреты подписи не добавляй в исходники.

Важно: workflow подготовлен, но из этой среды его нельзя запустить в твоём GitHub-репозитории без доступа к нему. Сам APK появится только после успешного выполнения GitHub Actions.
