Добавьте сюда лицензированные аудиофайлы проекта.
Рекомендуемые имена:
- sans_first_encounter.ogg
- hotel_rain_slow.ogg
- sans_final_battle.ogg
- room_ruins.ogg
- room_snowdin.ogg

Музыка The Murder и другие существующие композиции не включены в архив.
Используйте файлы только при наличии разрешения правообладателя.
