extends Node2D
## Dusttale: No Mercy — Build 0.7, сюжетное исследование Подземелья.
## Проект продолжает Build 0.6; новые комнаты и находки Сноудина добавлены поверх исходной логики.

const ROOMS := [
    {"name":"РУИНЫ", "subtitle":"Тишина под землёй", "color":Color("#30243c")},
    {"name":"СНОУДИН", "subtitle":"Снег помнит всё", "color":Color("#263746")},
    {"name":"ВОДОПАДЬЕ", "subtitle":"Следы под водой", "color":Color("#142d42")},
    {"name":"ХОТЛЕНД", "subtitle":"Жар и шёпот", "color":Color("#49302b")},
    {"name":"ЯДРО", "subtitle":"Слишком поздно", "color":Color("#302638")},
    {"name":"ОТЕЛЬ МТТ", "subtitle":"Столик у окна", "color":Color("#332735")},
    {"name":"ПОСЛЕДНЯЯ КОМНАТА", "subtitle":"Больше некуда бежать", "color":Color("#101017")}
]

var room := 0
var mode := "dialogue" # explore, dialogue, battle, ending
var hp := 20
var max_hp := 20
var player := Vector2(320, 205)
var soul := Vector2(320, 245)
var dialogue_lines: Array[String] = []
var dialogue_i := 0
var dialogue_speaker := ""
var dialogue_after := ""
var encounter_started := false
var battle_time := 0.0
var attack_clock := 0.0
var attack_phase := 0
var bullets: Array[Vector2] = []
var side_bullets: Array[Vector3] = [] # x, y, направление по X
var beam_x := -100.0
var beam_warning := 0.0
var beam_active := 0.0
var next_beam := 5.0
var invuln := 0.0
var interact_hint := "ИССЛЕДУЙТЕ КОМНАТУ"
var ending_text := ""
var save_flash := 0.0
var anim_time := 0.0
var cleared_rooms := {}
var save_path := "user://dusttale_save.cfg"
var encounter_kind := "intro"
var last_save_notice := ""
# Build 0.7: внутренние комнаты Сноудина и журнал находок.
var snowdin_room := 0 # 0 — тропа, 1 — домик, 2 — старый пост, 3 — скрытый проход
var discoveries: Dictionary = {}
var interaction_cooldown := 0.0
var player_facing := Vector2.DOWN

# Build 0.6: пошаговая боевая система.
var boss_hp := 40
var boss_max_hp := 40
var battle_menu := "commands" # commands, act, item, mercy, fight_timing, enemy_turn
var menu_index := 0
var fight_cursor := 0.0
var fight_direction := 1.0
var enemy_turn_timer := 0.0
var mercy_points := 0
var battle_message := "Санс смотрит на тебя."
var inventory := {"ПИРОГ": 2, "СНЕЖОК": 3}
var command_names := ["FIGHT", "ACT", "ITEM", "MERCY"]
var act_names := ["ПРОВЕРИТЬ", "ПОГОВОРИТЬ", "НАЗАД"]
var item_names := ["ПИРОГ (+10 HP)", "СНЕЖОК (+5 HP)", "НАЗАД"]
var mercy_names := ["ПОЩАДИТЬ", "НАЗАД"]

var move_dir := Vector2.ZERO
var held := {"left":false, "right":false, "up":false, "down":false}

func _save_game() -> void:
    var cfg := ConfigFile.new()
    cfg.set_value("progress", "room", room)
    cfg.set_value("progress", "hp", hp)
    cfg.set_value("progress", "encounter_started", encounter_started)
    cfg.set_value("progress", "cleared_rooms", cleared_rooms)
    cfg.set_value("progress", "snowdin_room", snowdin_room)
    cfg.set_value("progress", "discoveries", discoveries)
    cfg.set_value("progress", "player_x", player.x)
    cfg.set_value("progress", "player_y", player.y)
    var err := cfg.save(save_path)
    if err == OK:
        save_flash = 1.4
        last_save_notice = "ИГРА СОХРАНЕНА"

func _load_game() -> bool:
    var cfg := ConfigFile.new()
    if cfg.load(save_path) != OK:
        return false
    room = clampi(int(cfg.get_value("progress", "room", 0)), 0, ROOMS.size() - 1)
    hp = clampi(int(cfg.get_value("progress", "hp", max_hp)), 1, max_hp)
    encounter_started = bool(cfg.get_value("progress", "encounter_started", false))
    cleared_rooms = cfg.get_value("progress", "cleared_rooms", {})
    if typeof(cleared_rooms) != TYPE_DICTIONARY:
        cleared_rooms = {}
    # Restore Build 0.7 exploration state; defaults keep Build 0.6 saves compatible.
    snowdin_room = clampi(int(cfg.get_value("progress", "snowdin_room", 0)), 0, 3)
    discoveries = cfg.get_value("progress", "discoveries", {})
    if typeof(discoveries) != TYPE_DICTIONARY:
        discoveries = {}
    var saved_x := float(cfg.get_value("progress", "player_x", 320.0))
    var saved_y := float(cfg.get_value("progress", "player_y", 205.0))
    player = Vector2(clampf(saved_x, 34.0, 606.0), clampf(saved_y, 112.0, 296.0))
    mode = "explore"
    interact_hint = "Сохранение загружено. Продолжай путь."
    return true

func _ready() -> void:
    get_viewport().size_changed.connect(queue_redraw)
    _show_dialogue("", [
        "Ты снова спускаешься под землю.",
        "В этот раз что-то изменилось.",
        "Где-то впереди слышится тихий смешок..."
    ], "start")
    set_process(true)

func _process(delta: float) -> void:
    anim_time += delta
    save_flash = maxf(0.0, save_flash - delta)
    invuln = maxf(0.0, invuln - delta)
    move_dir = Vector2.ZERO
    if Input.is_action_pressed("ui_left") or held.left: move_dir.x -= 1
    if Input.is_action_pressed("ui_right") or held.right: move_dir.x += 1
    if Input.is_action_pressed("ui_up") or held.up: move_dir.y -= 1
    if Input.is_action_pressed("ui_down") or held.down: move_dir.y += 1

    if mode == "explore":
        if move_dir != Vector2.ZERO:
            player += move_dir.normalized() * 118.0 * delta
            player_facing = move_dir.normalized()
            player.x = clampf(player.x, 34, 606)
            player.y = clampf(player.y, 112, 296)
    elif mode == "battle":
        _update_battle(delta)
    queue_redraw()

func _show_dialogue(speaker: String, lines: Array, after: String) -> void:
    mode = "dialogue"
    dialogue_speaker = speaker
    dialogue_lines.clear()
    for line in lines:
        dialogue_lines.append(str(line))
    dialogue_i = 0
    dialogue_after = after

func _advance_dialogue() -> void:
    dialogue_i += 1
    if dialogue_i < dialogue_lines.size():
        return
    var action := dialogue_after
    dialogue_after = ""
    match action:
        "snowdin_free":
            mode = "explore"
        "start":
            mode = "explore"
            interact_hint = "Подойди к выходу справа"
        "sans_intro":
            _start_battle("intro")
        "intro_escape":
            mode = "explore"
            encounter_started = true
            cleared_rooms["0"] = true
            interact_hint = "Санс исчез. Нажми ДЕЙСТВИЕ, чтобы идти дальше."
            _save_game()
        "papyrus":
            mode = "explore"
            discoveries["papyrus_met"] = true
            interact_hint = "Папирус ушёл искать Санса. Исследуй Сноудин и скрытый проход."
            _save_game()
        "waterfall":
            mode = "explore"
            cleared_rooms["2"] = true
            interact_hint = "Кто-то наблюдает из темноты. Нажми ДЕЙСТВИЕ, чтобы идти дальше."
            _save_game()
        "hotland":
            mode = "explore"
            cleared_rooms["3"] = true
            interact_hint = "Впереди — вход в Ядро. Нажми ДЕЙСТВИЕ, чтобы идти дальше."
            _save_game()
        "core":
            mode = "explore"
            cleared_rooms["4"] = true
            interact_hint = "Отель МТТ уже близко. Нажми ДЕЙСТВИЕ, чтобы идти дальше."
            _save_game()
        "hotel":
            mode = "explore"
            cleared_rooms["5"] = true
            interact_hint = "Нажми ДЕЙСТВИЕ, чтобы идти дальше."
            _save_game()
        "final_intro":
            _start_battle("final")
        "final_win":
            mode = "ending"
            ending_text = "КОНЕЦ ПЕРВОЙ ГЛАВЫ"
            _save_game()
        "retry":
            _start_battle(encounter_kind)
        _:
            mode = "explore"

func _interact() -> void:
    if mode == "dialogue":
        _advance_dialogue()
        return
    if mode == "battle":
        return
    if mode == "ending":
        room = 0
        hp = max_hp
        player = Vector2(320, 205)
        cleared_rooms.clear()
        encounter_started = false
        _save_game()
        _show_dialogue("", ["Спасибо, что сыграл в прототип.", "История продолжится в следующей сборке."], "start")
        return

    # Сноудин в Build 0.7 — отдельная цепочка исследуемых комнат.
    if room == 1:
        if bool(cleared_rooms.get("1", false)):
            _go_room(2)
            _save_game()
        else:
            _interact_snowdin()
        return

    # Повторное взаимодействие после сюжетной сцены переводит в следующую локацию.
    if bool(cleared_rooms.get(str(room), false)):
        if room < ROOMS.size() - 1:
            _go_room(room + 1)
            _save_game()
        else:
            _show_dialogue("САНС", [
                "«всё. никаких шуток.»",
                "«если я остановлюсь сейчас, всё это будет зря.»",
                "Санс поднимает голову. В его глазнице вспыхивает красный свет."
            ], "final_intro")
        return

    match room:
        0:
            if not encounter_started:
                _show_dialogue("САНС", [
                    "«хех. привет, человек.»",
                    "«не самое удачное место для прогулки.»",
                    "Синий свет вспыхивает вокруг тебя."
                ], "sans_intro")
            else:
                cleared_rooms["0"] = true
                _go_room(1)
        1:
            _show_dialogue("ПАПИРУС", [
                "«ЧЕЛОВЕК! ТЫ НЕ ВИДЕЛ САНСА?»",
                "Папирус пытается улыбнуться, но тревога заметна даже сквозь шарф.",
                "Позже ты находишь лишь его шарф в снегу.",
                "Санс сделал это. И больше не шутит."
            ], "papyrus")
        2:
            _show_dialogue("", [
                "Вода уносит пепел в глубокую темноту.",
                "На стене нацарапано: «Я должен продолжать».",
                "Вдалеке слышен знакомый голос: «не подходи»."
            ], "waterfall")
        3:
            _show_dialogue("", [
                "На экранах мелькают записи наблюдения.",
                "На нескольких кадрах виден Санс.",
                "Он больше не пытается скрываться."
            ], "hotland")
        4:
            _show_dialogue("", [
                "Гул Ядра отдаётся в груди.",
                "Ты находишь список имён. Напротив каждого — отметка.",
                "Последняя строка написана дрожащим почерком: «я помню»."
            ], "core")
        5:
            _show_dialogue("САНС", [
                "Санс сидит за столиком у окна. Перед ним остывший кофе.",
                "«знаешь... иногда я думаю, что где-то в другом месте идёт дождь.»",
                "«там никто не считает. никто не возвращается. никто не ждёт, что я всё исправлю.»",
                "Он впервые смотрит прямо на тебя.",
                "«я не прошу прощения. я даже не знаю, заслужил ли право просить.»",
                "За окном тихо мерцают огни. Санс опускает глаза."
            ], "hotel")
        6:
            _show_dialogue("САНС", [
                "«всё. никаких шуток.»",
                "«если я остановлюсь сейчас, всё это будет зря.»",
                "Санс поднимает голову. В его глазнице вспыхивает красный свет."
            ], "final_intro")

func _snowdin_found(key: String) -> bool:
    return bool(discoveries.get(key, false))

func _record_discovery(key: String) -> void:
    discoveries[key] = true
    _save_game()

func _interact_snowdin() -> void:
    # Объекты активируются только рядом с игроком — осмотр требует исследования.
    if snowdin_room == 0:
        if player.distance_to(Vector2(430, 205)) < 58.0:
            _show_dialogue("ПАПИРУС", [
                "«ЧЕЛОВЕК! ПОДОЖДИ!»",
                "Папирус пытается говорить громко, но его голос дрожит.",
                "«САНС ПРОХОДИЛ ЗДЕСЬ. ОН НЕ ОТВЕТИЛ НА МОЙ ВОПРОС...»",
                "Он замечает следы у дерева и резко замолкает.",
                "«Я должен найти его. Пожалуйста... если встретишь — скажи, что я ищу»."
            ], "papyrus")
        elif player.distance_to(Vector2(115, 205)) < 58.0:
            _show_dialogue("ЗАМЁРЗШИЙ УКАЗАТЕЛЬ", [
                "Стрелка на табличке указывает к деревне.",
                "Под свежим слоем снега видна старая надпись: «НЕ ХОДИ ПО ОДНОМУ».",
                "Кто-то пытался стереть последние два слова."
            ], "snowdin_free")
        elif player.distance_to(Vector2(330, 205)) < 58.0:
            if not _snowdin_found("footprints"):
                _record_discovery("footprints")
                _show_dialogue("", [
                    "Следы идут рядом с твоими, но появляются на снегу раньше, чем ты делаешь шаг.",
                    "Они обрываются у дерева. На коре вырезан маленький череп."
                ], "snowdin_free")
            else:
                _show_dialogue("", ["Следы снова ведут к дереву. Новых отпечатков нет."], "snowdin_free")
        elif player.distance_to(Vector2(520, 205)) < 72.0:
            snowdin_room = 1
            player = Vector2(95, 220)
            interact_hint = "Домик у дороги. Осмотри вещи и дверь."
            _save_game()
        elif player.x > 585:
            snowdin_room = 2
            player = Vector2(85, 220)
            interact_hint = "Старый пост. Здесь давно никто не дежурил."
            _save_game()
        else:
            interact_hint = "Подойди к указателю, следам или домику."
    elif snowdin_room == 1:
        if player.distance_to(Vector2(170, 175)) < 65.0:
            if not _snowdin_found("note"):
                _record_discovery("note")
                _show_dialogue("ЗАПИСКА", [
                    "«Если снова услышишь шаги за окном — не открывай.",
                    "Снегопад не оставляет следов внутри дома.",
                    "Я проверял».",
                    "Бумага пахнет дымом. Подпись вырвана."
                ], "snowdin_free")
            else:
                _show_dialogue("", ["На столе лежит та же записка. Чернила почти выцвели."], "snowdin_free")
        elif player.distance_to(Vector2(430, 205)) < 65.0:
            if not _snowdin_found("cup"):
                _record_discovery("cup")
                _show_dialogue("", [
                    "На кружке написано «ЛУЧШЕМУ БРАТУ».",
                    "Внутри давно остыл какао. На дне лежит маленькая синяя пуговица."
                ], "snowdin_free")
            else:
                _show_dialogue("", ["Кружка холодная. Даже запах какао почти исчез."], "snowdin_free")
        elif player.x < 55:
            snowdin_room = 0
            player = Vector2(535, 220)
            interact_hint = "Ты вернулся на снежную тропу."
            _save_game()
        else:
            interact_hint = "Осмотри стол и кружку. Слева — выход."
    elif snowdin_room == 2:
        if player.distance_to(Vector2(300, 175)) < 75.0:
            if not _snowdin_found("logbook"):
                _record_discovery("logbook")
                _show_dialogue("ЖУРНАЛ ПОСТА", [
                    "Последняя запись сделана неровным почерком:",
                    "«Патруль отменён. Приказ пришёл из замка.",
                    "Говорят, король больше не принимает доклады.",
                    "А сегодня в лесу видели скелета, который шёл против следов».",
                    "На полях нарисован знакомый символ — красная точка в глазнице."
                ], "snowdin_free")
            else:
                _show_dialogue("", ["В журнале больше нет читаемых страниц."], "snowdin_free")
        elif player.distance_to(Vector2(570, 220)) < 45.0:
            snowdin_room = 3
            player = Vector2(85, 220)
            interact_hint = "За стеной оказался узкий скрытый проход."
            _save_game()
        elif player.distance_to(Vector2(500, 220)) < 55.0:
            if not _snowdin_found("cache"):
                _record_discovery("cache")
                _show_dialogue("", [
                    "За доской спрятан небольшой тканевый мешочек.",
                    "Внутри — старый жетон патруля и клочок карты с отметкой у лесной тропы."
                ], "snowdin_free")
            else:
                _show_dialogue("", ["Тайник пуст. На доске заметен след от недавно сдвинутой пыли."], "snowdin_free")
        elif player.x < 55:
            snowdin_room = 0
            player = Vector2(570, 220)
            interact_hint = "Ты вернулся к развилке."
            _save_game()
        else:
            interact_hint = "Осмотри журнал и стену. Справа — скрытая щель."
    else:
        if player.distance_to(Vector2(300, 180)) < 80.0:
            if not _snowdin_found("passage_message"):
                _record_discovery("passage_message")
                _show_dialogue("НАХОДКА", [
                    "За каменной стеной спрятан обрывок письма.",
                    "«Он просил меня забыть. Но как забыть того, кто каждый раз приходит снова?»",
                    "Ниже осталась только подпись: «А.»"
                ], "snowdin_free")
            else:
                _show_dialogue("", ["Пустой проход. На стене остался прямоугольный след от письма."], "snowdin_free")
        elif player.x < 55:
            snowdin_room = 2
            player = Vector2(570, 220)
            interact_hint = "Ты вернулся к старому посту."
            _save_game()
        elif player.x > 585:
            # The far end of the secret passage is the Snowdin exit.
            cleared_rooms["1"] = true
            _go_room(2)
            _save_game()
        else:
            interact_hint = "Узкий проход заканчивается обвалом. Осмотри стену или вернись."

func _go_room(next_room: int) -> void:
    room = clampi(next_room, 0, ROOMS.size() - 1)
    snowdin_room = 0
    player = Vector2(320, 205)
    save_flash = 1.2
    match room:
        1: interact_hint = "Подойди к фигуре впереди"
        2: interact_hint = "Осмотри следы у воды"
        3: interact_hint = "Осмотри записи"
        4: interact_hint = "Осмотри список"
        5: interact_hint = "Подойди к столику"
        6: interact_hint = "Подойди к Сансу"

func _start_battle(kind: String) -> void:
    encounter_kind = kind
    mode = "battle"
    battle_time = 0.0
    attack_clock = 0.0
    attack_phase = 0
    bullets.clear()
    side_bullets.clear()
    beam_x = -100.0
    beam_warning = 0.0
    beam_active = 0.0
    next_beam = 4.0
    soul = Vector2(320, 245)
    hp = max_hp
    boss_max_hp = 40 if kind == "intro" else 120
    boss_hp = boss_max_hp
    battle_menu = "commands"
    menu_index = 0
    fight_cursor = 0.0
    fight_direction = 1.0
    enemy_turn_timer = 0.0
    mercy_points = 0
    battle_message = "Санс смотрит на тебя."
    _show_battle_banner("САНС — НЕОЖИДАННАЯ ВСТРЕЧА" if kind == "intro" else "САНС — ПОСЛЕДНИЙ БОЙ")

func _show_battle_banner(text: String) -> void:
    interact_hint = text

func _battle_navigate(direction: int) -> void:
    if mode != "battle":
        return
    if battle_menu == "enemy_turn":
        return
    var count := 4
    if battle_menu == "act":
        count = act_names.size()
    elif battle_menu == "item":
        count = item_names.size()
    elif battle_menu == "mercy":
        count = mercy_names.size()
    elif battle_menu == "fight_timing":
        return
    menu_index = posmod(menu_index + direction, count)

func _battle_confirm() -> void:
    if mode != "battle":
        return
    match battle_menu:
        "commands":
            match menu_index:
                0:
                    battle_menu = "fight_timing"
                    fight_cursor = 0.0
                    fight_direction = 1.0
                    battle_message = "Нажми подтверждение ближе к центру!"
                1:
                    battle_menu = "act"
                    menu_index = 0
                2:
                    battle_menu = "item"
                    menu_index = 0
                3:
                    battle_menu = "mercy"
                    menu_index = 0
        "fight_timing":
            var accuracy := 1.0 - absf(fight_cursor - 0.5) * 2.0
            var damage := 4 + int(round(accuracy * (9 if encounter_kind == "intro" else 13)))
            boss_hp = maxi(0, boss_hp - damage)
            battle_message = "Попадание! Урон: %d" % damage
            if boss_hp <= 0:
                _battle_victory()
            else:
                _begin_enemy_turn()
        "act":
            match menu_index:
                0:
                    battle_message = "САНС — HP %d/%d. Он уклоняется от большинства атак." % [boss_hp, boss_max_hp]
                    _begin_enemy_turn()
                1:
                    mercy_points += 1
                    battle_message = "Ты пытаешься поговорить. Санс на миг отводит взгляд."
                    _begin_enemy_turn()
                _:
                    battle_menu = "commands"
                    menu_index = 0
        "item":
            match menu_index:
                0:
                    _use_battle_item("ПИРОГ", 10)
                1:
                    _use_battle_item("СНЕЖОК", 5)
                _:
                    battle_menu = "commands"
                    menu_index = 0
        "mercy":
            if menu_index == 1:
                battle_menu = "commands"
                menu_index = 0
            elif boss_hp <= int(boss_max_hp * 0.25) or mercy_points >= 2:
                _battle_spare()
            else:
                battle_message = "Санс пока не готов принять пощаду."
                _begin_enemy_turn()

func _battle_cancel() -> void:
    if battle_menu == "enemy_turn":
        return
    if battle_menu == "fight_timing":
        battle_menu = "commands"
        menu_index = 0
    elif battle_menu != "commands":
        battle_menu = "commands"
        menu_index = 0

func _use_battle_item(item_name: String, heal_amount: int) -> void:
    var amount := int(inventory.get(item_name, 0))
    if amount <= 0:
        battle_message = "Предмет закончился."
        return
    inventory[item_name] = amount - 1
    hp = mini(max_hp, hp + heal_amount)
    battle_message = "%s восстановил здоровье. HP %d/%d." % [item_name, hp, max_hp]
    _begin_enemy_turn()

func _begin_enemy_turn() -> void:
    battle_menu = "enemy_turn"
    enemy_turn_timer = 6.8
    battle_time = 0.0
    attack_clock = 0.25
    bullets.clear()
    side_bullets.clear()
    beam_warning = 0.0
    beam_active = 0.0
    next_beam = 2.6
    soul = Vector2(320, 245)
    invuln = 0.0

func _battle_spare() -> void:
    bullets.clear()
    side_bullets.clear()
    if encounter_kind == "intro":
        _show_dialogue("САНС", [
            "«хех. ладно. на сегодня хватит.»",
            "Санс опускает руки. Красный свет гаснет.",
            "«я ещё вернусь.» Он исчезает в синей вспышке."
        ], "intro_escape")
    else:
        _show_dialogue("САНС", [
            "Санс долго смотрит на тебя. Красный свет постепенно исчезает.",
            "«кажется... я устал считать.»",
            "Он закрывает глаза. В комнате становится тихо."
        ], "final_win")

func _battle_victory() -> void:
    bullets.clear()
    side_bullets.clear()
    if encounter_kind == "intro":
        _show_dialogue("САНС", [
            "«...неплохо.»",
            "Санс отступает. Красный свет гаснет.",
            "«я ещё вернусь.» Он исчезает в синей вспышке."
        ], "intro_escape")
    else:
        _show_dialogue("САНС", [
            "Санс тяжело опускает руки. Красный свет исчезает.",
            "«кажется... дождь всё-таки закончился.»",
            "В комнате становится тихо."
        ], "final_win")

func _update_battle(delta: float) -> void:
    if battle_menu == "fight_timing":
        fight_cursor += fight_direction * delta * 0.9
        if fight_cursor >= 1.0:
            fight_cursor = 1.0
            fight_direction = -1.0
        elif fight_cursor <= 0.0:
            fight_cursor = 0.0
            fight_direction = 1.0
        return
    if battle_menu != "enemy_turn":
        return

    battle_time += delta
    enemy_turn_timer -= delta
    attack_clock -= delta
    if attack_clock <= 0.0:
        attack_clock = maxf(0.34, 0.82 - float(attack_phase) * 0.13)
        var pattern := int(battle_time / 2.4) % 4
        if pattern == 0:
            var lane := randi_range(0, 3)
            for j in range(3):
                var x := 220.0 + float(j) * 66.0
                if j != lane:
                    bullets.append(Vector2(x, 86))
        elif pattern == 1:
            side_bullets.append(Vector3(190, randf_range(135, 300), 1))
            side_bullets.append(Vector3(450, randf_range(135, 300), -1))
        elif pattern == 2:
            bullets.append(Vector2(randf_range(215, 425), 82))
            if attack_phase > 0:
                bullets.append(Vector2(randf_range(215, 425), 82))
        else:
            side_bullets.append(Vector3(190, 215, 1))

    next_beam -= delta
    if next_beam <= 0.0 and beam_warning <= 0.0 and beam_active <= 0.0:
        beam_x = randf_range(225, 415)
        beam_warning = 0.85
        next_beam = maxf(2.7, 4.2 - float(attack_phase) * 0.5)
    if beam_warning > 0.0:
        beam_warning = maxf(0.0, beam_warning - delta)
        if beam_warning == 0.0:
            beam_active = 0.52
    elif beam_active > 0.0:
        beam_active = maxf(0.0, beam_active - delta)
        if absf(soul.x - beam_x) < 17.0 and invuln <= 0.0:
            hp -= 2
            invuln = 0.75

    if move_dir != Vector2.ZERO:
        soul += move_dir.normalized() * 178.0 * delta
    soul.x = clampf(soul.x, 202, 438)
    soul.y = clampf(soul.y, 108, 318)

    for i in range(bullets.size() - 1, -1, -1):
        bullets[i].y += (112.0 + float(attack_phase) * 27.0) * delta
        if bullets[i].distance_to(soul) < 15.0 and invuln <= 0.0:
            hp -= 1
            invuln = 0.65
        if bullets[i].y > 340:
            bullets.remove_at(i)

    for i in range(side_bullets.size() - 1, -1, -1):
        var b := side_bullets[i]
        b.x += b.z * (125.0 + float(attack_phase) * 35.0) * delta
        side_bullets[i] = b
        if Vector2(b.x, b.y).distance_to(soul) < 16.0 and invuln <= 0.0:
            hp -= 1
            invuln = 0.65
        if b.x < 185 or b.x > 455:
            side_bullets.remove_at(i)

    if battle_time > 10.0 and attack_phase == 0:
        attack_phase = 1
        interact_hint = "ФАЗА 2 — АТАКИ УСКОРЯЮТСЯ"
    if battle_time > 20.0 and attack_phase == 1:
        attack_phase = 2
        interact_hint = "ФАЗА 3 — GASTER BLASTER"

    if hp <= 0:
        hp = max_hp
        _show_dialogue("САНС", [
            "«не торопись. я тоже не сразу научился.»",
            "Ты приходишь в себя. Попробуй ещё раз."
        ], "retry")
        return
    if enemy_turn_timer <= 0.0:
        bullets.clear()
        side_bullets.clear()
        beam_warning = 0.0
        beam_active = 0.0
        battle_menu = "commands"
        menu_index = 0
        battle_message = "Твой ход."

func _draw() -> void:
    draw_rect(Rect2(0, 0, 640, 360), Color("#080910"))
    if mode == "battle":
        _draw_battle()
    elif mode == "ending":
        draw_string(ThemeDB.fallback_font, Vector2(185, 155), "DUSTTALE", HORIZONTAL_ALIGNMENT_LEFT, -1, 32, Color.WHITE)
        draw_string(ThemeDB.fallback_font, Vector2(185, 195), ending_text, HORIZONTAL_ALIGNMENT_LEFT, -1, 15, Color("#c9c3d2"))
        _draw_button("СНАЧАЛА", Rect2(480, 292, 135, 48))
    else:
        _draw_room()
        if mode == "dialogue":
            _draw_dialogue()
        else:
            _draw_hud()

func _draw_room() -> void:
    var data: Dictionary = ROOMS[room]
    draw_rect(Rect2(0, 48, 640, 312), data.color)
    draw_rect(Rect2(0, 48, 640, 4), Color("#8e8496"))
    # Pixel-art-like floor tiles and environmental details.
    for y in range(70, 350, 28):
        for x in range(16, 640, 40):
            draw_rect(Rect2(x + (14 if int(y / 28) % 2 == 0 else 0), y, 18, 2), Color(1, 1, 1, 0.045))
    match room:
        0:
            for x in [65, 545]:
                draw_rect(Rect2(x, 95, 30, 170), Color("#594965"))
                draw_rect(Rect2(x + 7, 110, 16, 140), Color("#211a2d"))
            draw_circle(Vector2(320, 112), 28, Color("#58465f"))
        1:
            if snowdin_room == 0:
                # Лесная тропа: фонари, сугробы, указатель и домик.
                for x in range(20, 640, 92):
                    draw_rect(Rect2(x, 100, 12, 82), Color("#172b3b"))
                    draw_colored_polygon(PackedVector2Array([Vector2(x-24,120),Vector2(x+6,65),Vector2(x+36,120)]), Color("#1b3445"))
                for x in range(40, 620, 72):
                    draw_rect(Rect2(x, 90, 34, 5), Color("#d5e6ef"))
                    draw_rect(Rect2(x + 9, 95, 18, 5), Color("#a6c5d7"))
                draw_rect(Rect2(0, 270, 640, 45), Color("#1b2938"))
                draw_rect(Rect2(112, 157, 7, 86), Color("#8b796e"))
                draw_rect(Rect2(88, 160, 55, 5), Color("#b9a58d"))
                draw_string(ThemeDB.fallback_font, Vector2(90,151), "ДЕРЕВНЯ", HORIZONTAL_ALIGNMENT_LEFT, -1, 9, Color("#f0e6d4"))
                draw_circle(Vector2(73, 169), 12, Color("#e5d59a"))
                draw_rect(Rect2(500, 151, 100, 88), Color("#594b4b"))
                draw_colored_polygon(PackedVector2Array([Vector2(487,155),Vector2(550,108),Vector2(613,155)]), Color("#3a303d"))
                draw_rect(Rect2(537, 190, 26, 49), Color("#211b29"))
                draw_rect(Rect2(505, 174, 18, 18), Color("#b8d7e2"))
                draw_circle(Vector2(330, 220), 3, Color("#d7e5ed"))
                draw_circle(Vector2(345, 225), 2, Color("#d7e5ed"))
                _draw_papyrus_placeholder(Vector2(430, 205))
            elif snowdin_room == 1:
                draw_rect(Rect2(35, 75, 570, 250), Color("#463c42"))
                for x in range(55, 600, 45):
                    draw_line(Vector2(x,80), Vector2(x,320), Color("#6a5658",0.55), 2)
                draw_rect(Rect2(115, 135, 112, 66), Color("#6c5146"))
                draw_rect(Rect2(130, 145, 82, 43), Color("#c4a27b"))
                draw_rect(Rect2(380, 155, 110, 65), Color("#684c43"))
                draw_rect(Rect2(394, 165, 82, 42), Color("#2b2935"))
                draw_rect(Rect2(145, 95, 54, 28), Color("#263e53"))
                draw_rect(Rect2(150, 100, 44, 18), Color("#a9c9d6"))
                draw_circle(Vector2(430, 145), 18, Color("#e4c17c",0.3))
                draw_rect(Rect2(275, 270, 90, 7), Color("#8a6a58"))
            elif snowdin_room == 2:
                draw_rect(Rect2(35, 75, 570, 250), Color("#30333a"))
                for x in range(65, 590, 70):
                    draw_rect(Rect2(x, 105, 8, 190), Color("#514b4b"))
                    draw_rect(Rect2(x+8, 105, 42, 8), Color("#514b4b"))
                draw_rect(Rect2(245, 110, 125, 125), Color("#544c47"))
                draw_rect(Rect2(260, 125, 95, 92), Color("#201f27"))
                draw_string(ThemeDB.fallback_font, Vector2(270,160), "ЖУРНАЛ", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("#d9d0c2"))
                draw_rect(Rect2(465, 185, 42, 55), Color("#6b5548"))
                draw_rect(Rect2(560, 165, 25, 110), Color("#1a1a20"))
                draw_rect(Rect2(556, 165, 5, 110), Color("#8c8278"))
            else:
                draw_rect(Rect2(35, 75, 570, 250), Color("#171820"))
                for x in range(70, 590, 55):
                    draw_line(Vector2(x, 95), Vector2(x+18, 310), Color("#45424b",0.55), 3)
                draw_rect(Rect2(245, 130, 150, 90), Color("#403d46"))
                draw_rect(Rect2(258, 142, 124, 66), Color("#211f28"))
                draw_string(ThemeDB.fallback_font, Vector2(270,180), "ОБРЫВОК", HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color("#b9b0a7"))
                draw_circle(Vector2(320, 250), 22, Color("#8793a0",0.12))

        2:
            # Waterfall pools, hanging crystals and reflected blue light.
            for x in range(0, 640, 52):
                draw_rect(Rect2(x, 260 + sin(float(x)) * 8, 45, 65), Color("#1d526d"))
            for i in range(18):
                draw_circle(Vector2(fposmod(i * 79.0, 630.0), 100 + fposmod(i * 47.0, 145.0)), 2, Color("#7db9d0"))
            for x in [95, 180, 470, 555]:
                draw_colored_polygon(PackedVector2Array([Vector2(x, 90), Vector2(x + 10, 118), Vector2(x + 2, 145), Vector2(x - 7, 116)]), Color("#73b9d0", 0.75))
        3:
            for x in range(50, 620, 100):
                draw_rect(Rect2(x, 90, 55, 185), Color("#7a4238"))
                draw_rect(Rect2(x + 8, 105, 39, 155), Color("#e17c43"))
        4:
            for x in range(0, 640, 80):
                draw_rect(Rect2(x, 75, 8, 245), Color("#6d506c"))
            draw_rect(Rect2(100, 115, 440, 9), Color("#b88a9c"))
            draw_rect(Rect2(100, 235, 440, 9), Color("#b88a9c"))
        5:
            # MTT lounge window and warm lamps.
            draw_rect(Rect2(205, 78, 230, 68), Color("#192e45"))
            draw_rect(Rect2(214, 86, 212, 52), Color("#39546c"))
            for x in range(225, 425, 28):
                draw_line(Vector2(x, 90), Vector2(x - 22, 135), Color("#a9c2d0", 0.22), 2)
            draw_circle(Vector2(115, 128), 18, Color("#e6bb72", 0.15))
            draw_circle(Vector2(525, 128), 18, Color("#e6bb72", 0.15))
            draw_rect(Rect2(205, 154, 230, 92), Color("#6b4a4a"))
            draw_rect(Rect2(220, 164, 200, 72), Color("#34252d"))
            draw_rect(Rect2(250, 173, 140, 6), Color("#bd9a7e"))
            _draw_sans_placeholder(Vector2(320, 125), false)
            draw_string(ThemeDB.fallback_font, Vector2(264, 266), "СТОЛИК У ОКНА", HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color("#e8d8c7"))
        6:
            draw_rect(Rect2(0, 48, 640, 312), Color("#08080d"))
            _draw_sans_placeholder(Vector2(320, 165), true)
    if room != 5 and room != 6:
        _draw_player(player)
    draw_rect(Rect2(0, 0, 640, 48), Color("#10111a"))
    draw_string(ThemeDB.fallback_font, Vector2(18, 22), "DUSTTALE", HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color("#f0eaf5"))
    var room_label := data.name + "  /  " + data.subtitle
    if room == 1:
        room_label = ["СНОУДИН / ЛЕСНАЯ ТРОПА", "СНОУДИН / ДОМИК У ДОРОГИ", "СНОУДИН / СТАРЫЙ ПОСТ", "СНОУДИН / СКРЫТЫЙ ПРОХОД"][snowdin_room]
    draw_string(ThemeDB.fallback_font, Vector2(18, 40), room_label, HORIZONTAL_ALIGNMENT_LEFT, -1, 10, Color("#bdb4c8"))
    draw_string(ThemeDB.fallback_font, Vector2(520, 27), "HP %d/%d" % [hp, max_hp], HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("#f0d2d2"))
    if save_flash > 0.0:
        draw_string(ThemeDB.fallback_font, Vector2(510, 45), "СОХРАНЕНО", HORIZONTAL_ALIGNMENT_LEFT, -1, 8, Color("#b8d8b7"))

func _draw_player(pos: Vector2) -> void:
    var step := absf(sin(anim_time * 8.0)) * 2.0
    draw_rect(Rect2(pos.x - 10, pos.y + 16, 20, 4), Color(0, 0, 0, 0.25))
    draw_rect(Rect2(pos.x - 7, pos.y - 13, 14, 13), Color("#d8b99e"))
    draw_rect(Rect2(pos.x - 8, pos.y - 15, 16, 6), Color("#5a3b34"))
    draw_rect(Rect2(pos.x - 8, pos.y - 1, 16, 15), Color("#8f4051"))
    draw_rect(Rect2(pos.x - 8, pos.y + 2, 16, 4), Color("#c05a69"))
    draw_rect(Rect2(pos.x - 7 - step, pos.y + 12, 5, 6), Color("#302b38"))
    draw_rect(Rect2(pos.x + 2 + step, pos.y + 12, 5, 6), Color("#302b38"))

func _draw_sans_placeholder(pos: Vector2, angry: bool) -> void:
    # Авторская процедурная пиксельная заглушка: силуэт, одежда и мимика.
    var bob := sin(anim_time * 2.4) * 1.5
    var p := pos + Vector2(0, bob)
    # Тень и ботинки.
    draw_rect(Rect2(p.x - 20, p.y + 43, 40, 5), Color(0, 0, 0, 0.28))
    draw_rect(Rect2(p.x - 17, p.y + 34, 13, 8), Color("#202331"))
    draw_rect(Rect2(p.x + 4, p.y + 34, 13, 8), Color("#202331"))
    # Шорты и куртка.
    draw_rect(Rect2(p.x - 18, p.y + 18, 36, 18), Color("#e8e8ef"))
    draw_rect(Rect2(p.x - 20, p.y + 2, 40, 24), Color("#e8e8ef"))
    draw_rect(Rect2(p.x - 18, p.y + 7, 36, 12), Color("#263b68"))
    draw_rect(Rect2(p.x - 22, p.y + 1, 8, 19), Color("#263b68"))
    draw_rect(Rect2(p.x + 14, p.y + 1, 8, 19), Color("#263b68"))
    draw_rect(Rect2(p.x - 5, p.y + 7, 10, 12), Color("#d9dce8"))
    # Череп с широкой челюстью.
    draw_rect(Rect2(p.x - 18, p.y - 30, 36, 31), Color("#f0eff2"))
    draw_rect(Rect2(p.x - 14, p.y - 35, 28, 8), Color("#f0eff2"))
    draw_rect(Rect2(p.x - 13, p.y - 3, 26, 7), Color("#d7d6df"))
    draw_rect(Rect2(p.x - 9, p.y + 1, 4, 3), Color("#34323d"))
    draw_rect(Rect2(p.x - 2, p.y + 1, 4, 3), Color("#34323d"))
    draw_rect(Rect2(p.x + 5, p.y + 1, 4, 3), Color("#34323d"))
    # Глазницы и фирменная улыбка.
    draw_rect(Rect2(p.x - 12, p.y - 22, 9, 9), Color("#171722"))
    draw_rect(Rect2(p.x + 3, p.y - 22, 9, 9), Color("#171722"))
    if angry:
        draw_rect(Rect2(p.x + 4, p.y - 21, 7, 8), Color("#d51f37"))
        draw_rect(Rect2(p.x + 6, p.y - 19, 3, 4), Color("#fff0f0"))
    else:
        draw_rect(Rect2(p.x + 5, p.y - 20, 4, 3), Color("#b8c5e9"))
    draw_rect(Rect2(p.x - 7, p.y - 7, 14, 2), Color("#777783"))
    draw_rect(Rect2(p.x - 5, p.y - 5, 10, 2), Color("#777783"))

func _draw_papyrus_placeholder(pos: Vector2) -> void:
    # Высокий силуэт, наплечники и красный шарф — всё нарисовано примитивами.
    var sway := sin(anim_time * 1.7) * 1.0
    var p := pos + Vector2(sway, 0)
    draw_rect(Rect2(p.x - 18, p.y + 36, 14, 7), Color("#e9e8e5"))
    draw_rect(Rect2(p.x + 4, p.y + 36, 14, 7), Color("#e9e8e5"))
    draw_rect(Rect2(p.x - 17, p.y + 10, 34, 29), Color("#eeeef0"))
    draw_rect(Rect2(p.x - 23, p.y + 8, 12, 13), Color("#eeeef0"))
    draw_rect(Rect2(p.x + 11, p.y + 8, 12, 13), Color("#eeeef0"))
    draw_rect(Rect2(p.x - 19, p.y + 19, 38, 8), Color("#a92f3d"))
    draw_rect(Rect2(p.x + 11, p.y + 23, 8, 20), Color("#a92f3d"))
    draw_rect(Rect2(p.x - 13, p.y - 24, 26, 32), Color("#f2f0ed"))
    draw_rect(Rect2(p.x - 17, p.y - 17, 34, 19), Color("#f2f0ed"))
    draw_rect(Rect2(p.x - 13, p.y - 8, 26, 6), Color("#d7d4d2"))
    draw_rect(Rect2(p.x - 10, p.y - 17, 7, 6), Color("#28242c"))
    draw_rect(Rect2(p.x + 3, p.y - 17, 7, 6), Color("#28242c"))
    draw_rect(Rect2(p.x - 8, p.y - 5, 16, 2), Color("#8c8588"))
    # Перья/гребень шлема.
    draw_colored_polygon(PackedVector2Array([
        Vector2(p.x - 13, p.y - 23), Vector2(p.x - 9, p.y - 36),
        Vector2(p.x - 2, p.y - 25), Vector2(p.x + 4, p.y - 39),
        Vector2(p.x + 9, p.y - 24), Vector2(p.x + 15, p.y - 31),
        Vector2(p.x + 14, p.y - 18)
    ]), Color("#f1f0ed"))
    draw_rect(Rect2(p.x - 19, p.y + 11, 38, 4), Color("#c7c5c9"))

func _draw_hud() -> void:
    draw_string(ThemeDB.fallback_font, Vector2(18, 337), interact_hint, HORIZONTAL_ALIGNMENT_LEFT, 420, 11, Color("#e9e5ee"))
    _draw_controls()
    _draw_button("ДЕЙСТВИЕ", Rect2(480, 292, 135, 48))
    _draw_button("SAVE", Rect2(480, 245, 135, 34), Color("#343b4b"))

func _draw_dialogue() -> void:
    draw_rect(Rect2(22, 242, 596, 104), Color("#08080d"))
    draw_rect(Rect2(22, 242, 596, 104), Color("#e7e4ed"), false, 2)
    if dialogue_speaker != "":
        draw_string(ThemeDB.fallback_font, Vector2(40, 262), dialogue_speaker, HORIZONTAL_ALIGNMENT_LEFT, -1, 10, Color("#f2d36d"))
    var line := dialogue_lines[dialogue_i] if dialogue_i < dialogue_lines.size() else ""
    draw_string(ThemeDB.fallback_font, Vector2(40, 289), line, HORIZONTAL_ALIGNMENT_LEFT, 548, 13, Color.WHITE)
    _draw_button("ДАЛЬШЕ ▶", Rect2(480, 298, 125, 38))
    _draw_controls()

func _draw_battle() -> void:
    draw_rect(Rect2(0, 0, 640, 360), Color("#080910"))
    draw_string(ThemeDB.fallback_font, Vector2(18, 24), "САНС", HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color.WHITE)
    draw_string(ThemeDB.fallback_font, Vector2(18, 43), "HP %d/%d" % [hp, max_hp], HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color("#f2d0d0"))
    draw_rect(Rect2(18, 51, 130, 8), Color("#44232d"))
    draw_rect(Rect2(18, 51, 130.0 * float(hp) / float(max_hp), 8), Color("#e64b59"))
    draw_string(ThemeDB.fallback_font, Vector2(470, 24), "САНС  %d/%d" % [boss_hp, boss_max_hp], HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("#f2d0d0"))
    draw_rect(Rect2(470, 32, 150, 9), Color("#44232d"))
    draw_rect(Rect2(470, 32, 150.0 * float(boss_hp) / float(boss_max_hp), 9), Color("#e64b59"))
    _draw_sans_placeholder(Vector2(320, 65), attack_phase > 0)
    draw_rect(Rect2(190, 100, 260, 225), Color.BLACK)
    draw_rect(Rect2(190, 100, 260, 225), Color.WHITE, false, 3)

    if battle_menu == "enemy_turn":
        for b in bullets:
            draw_rect(Rect2(b.x - 4, b.y - 10, 8, 20), Color("#f1f1f7"))
        for b in side_bullets:
            draw_rect(Rect2(b.x - 10, b.y - 4, 20, 8), Color("#f1f1f7"))
        if beam_warning > 0.0:
            draw_line(Vector2(beam_x, 104), Vector2(beam_x, 324), Color(1.0, 0.2, 0.25, 0.75), 3.0)
            draw_string(ThemeDB.fallback_font, Vector2(beam_x - 24, 95), "!", HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color("#ff5964"))
        elif beam_active > 0.0:
            draw_rect(Rect2(beam_x - 15, 102, 30, 222), Color(0.35, 0.8, 1.0, 0.85))
            draw_rect(Rect2(beam_x - 5, 102, 10, 222), Color.WHITE)
        if invuln <= 0.0 or int(Time.get_ticks_msec() / 90) % 2 == 0:
            draw_circle(soul, 7, Color("#ff343f"))
        draw_string(ThemeDB.fallback_font, Vector2(210, 342), "АТАКА САНСА — уклоняйся", HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color("#ddd8e5"))
        _draw_controls()
    else:
        draw_string(ThemeDB.fallback_font, Vector2(210, 142), battle_message, HORIZONTAL_ALIGNMENT_LEFT, 220, 12, Color("#e9e5ee"))
        if battle_menu == "fight_timing":
            draw_string(ThemeDB.fallback_font, Vector2(210, 190), "ШКАЛА УДАРА", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color.WHITE)
            draw_rect(Rect2(215, 208, 210, 18), Color("#3a303b"))
            draw_rect(Rect2(215 + 210.0 * fight_cursor - 4, 202, 8, 30), Color("#f3d36b"))
            draw_rect(Rect2(310, 208, 20, 18), Color("#68c78a"))
            _draw_button("УДАРИТЬ", Rect2(250, 245, 140, 34))
        else:
            var labels: Array = command_names
            if battle_menu == "act":
                labels = act_names
            elif battle_menu == "item":
                labels = item_names
            elif battle_menu == "mercy":
                labels = mercy_names
            var shown := labels.size()
            for i in range(shown):
                var x := 28.0 + float(i % 2) * 302.0
                var y := 250.0 + float(i / 2) * 48.0
                var selected := i == menu_index
                var label_text := str(labels[i])
                if battle_menu == "item" and i == 0:
                    label_text = "ПИРОГ x%d" % int(inventory.get("ПИРОГ", 0))
                elif battle_menu == "item" and i == 1:
                    label_text = "СНЕЖОК x%d" % int(inventory.get("СНЕЖОК", 0))
                _draw_button(("▶ " if selected else "  ") + label_text, Rect2(x, y, 280, 38), Color("#72523d") if selected else Color("#34313e"))
    draw_string(ThemeDB.fallback_font, Vector2(18, 350), "← → ↑ ↓ / ENTER или Z / X — назад", HORIZONTAL_ALIGNMENT_LEFT, -1, 9, Color("#aaa3b4"))

func _draw_controls() -> void:
    var base := Color(1, 1, 1, 0.18)
    _draw_button("◀", Rect2(16, 292, 42, 42), base)
    _draw_button("▶", Rect2(108, 292, 42, 42), base)
    _draw_button("▲", Rect2(62, 246, 42, 42), base)
    _draw_button("▼", Rect2(62, 338, 42, 20), base)

func _draw_button(label: String, rect: Rect2, color: Color = Color("#493c50")) -> void:
    draw_rect(rect, color)
    draw_rect(rect, Color("#d9d3df"), false, 1)
    draw_string(ThemeDB.fallback_font, Vector2(rect.position.x + 9, rect.position.y + rect.size.y * 0.67), label, HORIZONTAL_ALIGNMENT_LEFT, rect.size.x - 8, 12, Color.WHITE)

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        _touch(event.position, event.pressed)
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        _touch(event.position, event.pressed)
    elif event is InputEventKey and event.pressed and not event.echo:
        if mode == "battle":
            if event.keycode == KEY_UP or event.keycode == KEY_LEFT:
                _battle_navigate(-1)
            elif event.keycode == KEY_DOWN or event.keycode == KEY_RIGHT:
                _battle_navigate(1)
            elif event.keycode == KEY_ENTER or event.keycode == KEY_SPACE or event.keycode == KEY_Z:
                _battle_confirm()
            elif event.keycode == KEY_X or event.keycode == KEY_ESCAPE:
                _battle_cancel()
        else:
            if event.keycode == KEY_ENTER or event.keycode == KEY_SPACE or event.keycode == KEY_Z:
                _interact()
            elif event.keycode == KEY_F5:
                _save_game()
            elif event.keycode == KEY_F9:
                if not _load_game():
                    interact_hint = "Сохранение не найдено."

func _touch(pos: Vector2, pressed: bool) -> void:
    if not pressed:
        held.left = false
        held.right = false
        held.up = false
        held.down = false
        return

    if mode == "battle":
        if battle_menu == "enemy_turn":
            if pos.x < 65 and pos.y > 280:
                held.left = true
            elif pos.x < 160 and pos.y > 280:
                held.right = true
            elif pos.x < 112 and pos.y > 235 and pos.y <= 290:
                held.up = true
            elif pos.x < 112 and pos.y > 325:
                held.down = true
            return
        if battle_menu == "fight_timing":
            if pos.y > 195:
                _battle_confirm()
            else:
                _battle_cancel()
            return
        if pos.y >= 245 and pos.y < 335:
            var col := 0 if pos.x < 320 else 1
            var row := 0 if pos.y < 293 else 1
            var idx := row * 2 + col
            var max_idx := 3
            if battle_menu == "act":
                max_idx = act_names.size() - 1
            elif battle_menu == "item":
                max_idx = item_names.size() - 1
            elif battle_menu == "mercy":
                max_idx = mercy_names.size() - 1
            menu_index = clampi(idx, 0, max_idx)
            _battle_confirm()
        elif pos.x < 120 and pos.y < 240:
            _battle_cancel()
        return

    if pos.x < 65 and pos.y > 280:
        held.left = true
    elif pos.x < 160 and pos.y > 280:
        held.right = true
    elif pos.x < 112 and pos.y > 235 and pos.y <= 290:
        held.up = true
    elif pos.x < 112 and pos.y > 325:
        held.down = true
    elif pos.x > 470 and pos.y > 285:
        _interact()
    elif pos.x > 470 and pos.y > 235 and pos.y <= 285:
        _save_game()
    elif mode == "dialogue":
        _advance_dialogue()
