#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
GODOT_BIN="${GODOT_BIN:-godot}"
command -v "$GODOT_BIN" >/dev/null 2>&1 || { echo "Не найден Godot 4.3. Установи движок и задай GODOT_BIN при необходимости."; exit 1; }
mkdir -p "$ROOT/build"
"$GODOT_BIN" --headless --path "$ROOT" --editor --quit
"$GODOT_BIN" --headless --path "$ROOT" --export-debug "Android" "$ROOT/build/Dusttale_No_Mercy_0.7.1.apk"
test -s "$ROOT/build/Dusttale_No_Mercy_0.7.1.apk"
echo "APK создан: $ROOT/build/Dusttale_No_Mercy_0.7.1.apk"
